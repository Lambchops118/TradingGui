#Name     : Live Pie chart test
#Date     : 1 June 2022
#Function : Demonstate a live updating pie chart to be used with
#           the trading AI

import tkinter
from tkinter import *
import numpy
import matplotlib
import matplotlib.figure
import matplotlib.patches
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

root = Tk()
lab = Label(root)
lab.pack()

def update():
    fig = matplotlib.figure.Figure(figsize=(4,4))
    ax = fig.add_subplot(111)
    ax.pie([10, 10, 10, 10, 10])
    ax.legend(["ETC", "EOS", "DOGE", "ENJ", "APE"])

    #window = tkinter.Tk()
    canvas = FigureCanvasTkAgg(fig, master= root)
    canvas.get_tk_widget().pack()
    canvas.draw()
    #window.mainloop()

    #root.after(1000, update())

update()
root.mainloop()
