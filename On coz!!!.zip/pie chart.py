#Name     : Pie chart testbed
#Date     : 1 June 2022
#Function : Creates a pie chart for the coins traded by the AI

##import tkinter as tk
##import matplotlib.pyplot as plt

##from tkinter import *
##from tkinter import ttk
##root = Tk()
##frm = ttk.Frame(root, padding=100)
##frm.grid()
##ttk.Label(frm, text="This is a trial line").grid(column=1, row=0)
##ttk.Button(frm, text="This is a trial line", command=root.destroy).grid(column=1, row=0)
##root.mainloop()


##class App(tk.Frame):
##    def __init__(self, master):
##        super().__init__(master)
##        self.pack()
##
##        self.entrythingy = tk.Entry()
##        self.entrythingy.pack()
##
##        # Create the application variable.
##        self.contents = tk.StringVar()
##        # Set it to some value.
##        self.contents.set("this is a variable")
##        # Tell the entry widget to watch this variable.
##        self.entrythingy["textvariable"] = self.contents
##
##        # Define a callback for when the user hits return.
##        # It prints the current value of the variable.
##        self.entrythingy.bind('<Key-Return>',
##                             self.print_contents)
##
##    def print_contents(self, event):
##        print("Hi. The current entry content is:",
##              self.contents.get())


##class App(tk.Frame):
##    def __init__(self, master=None):
##        super().__init__(master)
##        self.pack()
##
### create the application
##myapp = App()
##
###
### here are method calls to the window manager class
###
##myapp.master.title("My Do-Nothing Application")
##myapp.master.maxsize(1000, 400)
##
### start the program
##myapp.mainloop()
##
##root = tk.Tk()
##myapp = App(root)
##myapp.mainloop()



# Pie chart, where the slices will be ordered and plotted counter-clockwise:
##labels = 'ETC', 'EOS', 'VTC', 'DOGE'
##sizes = [1, 1, 1, 1]
###explode = (0, 0, 0, 0)  # only "explode" the 2nd slice (i.e. 'Hogs')
##
##fig1, ax1 = plt.subplots()
##ax1.pie(sizes, labels=labels, autopct='%1.1f%%',
##        shadow=True, startangle=90)
##ax1.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
##
##plt.show()


import matplotlib.pyplot as plt
from time import sleep
for i in range(100):
   plt.pie([100-i, i])
   plt.pause(.001)
   plt.draw()
   sleep(0.1)
