#Name     : Tkinter GUI basic framework v1
#Date     : 4 June 2022
#Function : Create a basic framework for the GUI window. Then re-write and commit to gitlab

import tkinter as tk
import matplotlib
matplotlib.use("TkAgg")
from datetime import datetime, timedelta
import random
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg#, NavigationToolbar2TkAgg
from matplotlib.figure import Figure
import matplotlib.animation as animation
from matplotlib import style
from tkinter import ttk
import matplotlib.dates as mdates

LARGE_FONT = ("Verdana", 12)
style.use("ggplot")
f = Figure(figsize=(5,5), dpi=100)
a = f.add_subplot(111)

def animate(dateTimeObject,numPoints):
    #a.clear()
    #a.plot([35, 49, 44], [144, 13, 73])

    None

    #x_data = [dateTimeObject + timedelta(seconds = 1) for i in range(numPoints)]
    #y_data = [0 for i in range(numPoints)]

    #x_data.append(datetime.now())
    #value = random.randint(0, 100)
    #print(value)
    #y_data.append(value) #Random integer from 0-100

    #Delete oldest data point
    #x_data = x_data[1:]
    #y_data = y_data[1:]

    #update data on the graph
    #figure = Figure(figsize = (5,5), dpi = 100)
    #ax = figure.add_subplot(111)
    #plot = ax.plot(x_data, y_data, label = "STONKS")[0]
    #plot.set_xdata(x_data)
    #plot.set_ydata(y_data)
    #ax.set_xlim(x_data[0], x_data[-1])
    #canvas = FigureCanvasTkAgg(figure)
    #canvas.get_tk_widget().pack(side = tk.BOTTOM, fill = tk.BOTH, expand = True)
    #canvas.draw_idle()
    #after(1000, animate) #update every second


class GUI_APP(tk.Tk): #Main class to contain all other windows' classes.
    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)

        tk.Tk.wm_title(self, "Trading Algorithm")

        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand = True)
        #container.grid_rowconfigure(0, weight =1)
        #container.grid_columnconfigure(0, weight=1)

        self.frames = {}

        for F in (MainPage, SettingsPage):
            frame = F(container, self, numPoints=10000)
            self.frames[F] = frame
            frame.grid(row = 0, column=0, sticky="nsew")

        self.show_frame(MainPage)

    def show_frame(self, cont):
        frame = self.frames[cont]
        frame.tkraise()

class MainPage(tk.Frame): #Class file for the main screen where live graph is drawn.
    def __init__(self, parent, controller, numPoints):
        tk.Frame.__init__(self, parent)

        self.figure = Figure(figsize = (5,5), dpi = 100)
        self.ax = self.figure.add_subplot(111)

        format = mdates.DateFormatter("%H:%M:%S")
        self.ax.xaxis.set_major_formatter(format)

        #self.ax.xaxis.set_major_formatter(str(numPoints))

        dateTimeObject = datetime.now() + timedelta(seconds = -numPoints) #Difference between start and current time

        self.x_data = [dateTimeObject + timedelta(seconds = 1) for i in range(numPoints)]
        self.y_data = [0 for i in range(numPoints)]

        #Create the graph
        self.plot = self.ax.plot(self.x_data, self.y_data, label = "STONKS")[0]
        self.ax.set_ylim(0,100)
        self.ax.set_xlim(self.x_data[0], self.x_data[-1])

        #Create the window or "canvas"
        label = tk.Label(self, text = "Graph page")
        label.pack(pady=10, padx=10)
        self.canvas = FigureCanvasTkAgg(self.figure, self)
        self.canvas.get_tk_widget().pack(side=tk.BOTTOM, fill = tk.BOTH, expand = True)

        #Stuff from multi page code
        button = ttk.Button(self, text="settings", command = lambda: controller.show_frame(SettingsPage))
        button.pack()

    def animate(self):
            self.x_data.append(datetime.now())
            value = random.randint(0, 100)
            print(value)
            self.y_data.append(value)

            #Delete oldest data point -- this is a proof of concept this will not be used
            self.x_data = self.x_data[1:]
            self.y_data = self.y_data[1:]

            #update data on the graph
            self.plot.set_xdata(self.x_data)
            self.plot.set_ydata(self.y_data)
            self.ax.set_xlim(self.x_data[0], self.x_data[-1])
            self.canvas.draw_idle()
            self.after(1000, self.animate) #update on the second

class SettingsPage(tk.Frame):
    def __init__(self, parent, controller, numPoints):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text = "Settings", font=LARGE_FONT)
        label.pack(pady=10, padx=10)

        button1 = ttk.Button(self, text="Return to main", command=lambda: controller.show_frame(MainPage))
        button1.pack()


#root = tk.Tk()
#graph = MainPage(root, numPoints = 100, controller=1000)
#graph.pack(fill = 'both', expand = False)
#root.geometry("500x400")
#graph.animate()
#root.mainloop()

app = GUI_APP()
ani = animation.FuncAnimation(f, animate, interval=1000)
app.mainloop()
