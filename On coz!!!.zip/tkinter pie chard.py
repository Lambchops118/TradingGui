#Name      : Pie chart in tkinter
#Date      : 1 June 2022
#Function  : Pie chart in tkinter for trading AI
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.figure
import matplotlib.patches
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk

fig = matplotlib.figure.Figure(figsize=(4,4))
ax = fig.add_subplot(111)
ax.pie([10, 10, 10, 10, 10]) 
ax.legend(["ETC","EOS","DOGE","ENJ","APE"])



#circle=matplotlib.patches.Circle( (0,0), 0.7, color='black')
#ax.add_artist(circle)

window= tk.Tk()
canvas = FigureCanvasTkAgg(fig, master=window)
canvas.get_tk_widget().pack()
canvas.draw()
window.mainloop()
