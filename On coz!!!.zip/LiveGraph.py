#Name     : Tkinter live graph
#Date     : 2 June 2022
#Function : Demonstrates the use of live-updating graphs for use with trading AI

import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import matplotlib.dates as mdates
from datetime import datetime, timedelta
import random

class GraphWindow(tk.Frame):
    def __init__(self, parent, numPoints): #Where numPoints is number of points on the graph
        tk.Frame.__init__(self, parent)

        #Matplotlib Figure
        self.figure = Figure(figsize = (5,5), dpi = 100)
        self.ax = self.figure.add_subplot(111)

        #Format x axis as time axis
        #format = mdates.DateFormatter("%H:%M:%S")
        #self.ax.xaxis.set_major_formatter(format)
        self.ax.xaxis.set_major_formatter(str(numPoints))

        #initial data for x and y axes
        dateTimeObject = datetime.now() + timedelta(seconds = -numPoints) #difference between start time and current time

        self.x_data = [dateTimeObject + timedelta(seconds = 1) for i in range(numPoints)]
        self.y_data = [0 for i in range(numPoints)]

        #Create the graph
        self.plot = self.ax.plot(self.x_data, self.y_data, label = "STONKS")[0]
        self.ax.set_ylim(0, 100)
        self.ax.set_xlim(self.x_data[0], self.x_data[-1])

        #Create the window or "canvas"
        label = tk.Label(self, text = "Live Graph with Tkinter example")
        label.pack(pady=10, padx=10)
        self.canvas = FigureCanvasTkAgg(self.figure, self)
        self.canvas.get_tk_widget().pack(side = tk.BOTTOM, fill = tk.BOTH, expand = True)

    def animate(self):
        #append data with new point
        self.x_data.append(datetime.now())
        value = random.randint(0, 100)
        print(value)
        self.y_data.append(value) #Random integer from 0-100

        #Delete oldest data point
        self.x_data = self.x_data[1:]
        self.y_data = self.y_data[1:]

        #update data on the graph
        self.plot.set_xdata(self.x_data)
        self.plot.set_ydata(self.y_data)
        self.ax.set_xlim(self.x_data[0], self.x_data[-1])
        self.canvas.draw_idle()
        self.after(1000, self.animate) #update every second

root = tk.Tk()
graph = GraphWindow(root, numPoints=100)
graph.pack(fill = 'both', expand = False)
root.geometry("500x400")
graph.animate()
root.mainloop()















