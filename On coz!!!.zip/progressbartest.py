from tkinter import *
from tkinter.ttk import *
import time

ws=Tk()
Progress_Bar=Progressbar(ws,orient=HORIZONTAL,length=250,mode='determinate')

def Slide():
    #Progress_Bar['value']=20
    #ws.update_idletasks()
    #time.sleep(1)
    #Progress_Bar['value']=50
    #ws.update_idletasks()
    #time.sleep(1)
    #Progress_Bar['value']=80
    #ws.update_idletasks()
    #time.sleep(1)
    #Progress_Bar['value']=100

    for x in range(0, 100):
        Progress_Bar['value'] = x
        ws.update_idletasks()
        time.sleep(0.1)

Progress_Bar.pack()
Button(ws,text='Run',command=Slide).pack(pady=10)
mainloop()